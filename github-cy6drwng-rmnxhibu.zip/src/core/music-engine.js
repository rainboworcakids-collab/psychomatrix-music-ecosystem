// ============================================================
// music-modules.js - เวอร์ชัน 2.5
// หน้าที่หลัก: โมดูลสร้างเพลงและจัดการข้อมูลส่วนบุคคล
// ------------------------------------------------------------
// ประกอบด้วย:
// 1. Music Generator - สร้างเพลงจากข้อมูลส่วนบุคคล
// 2. Data Processor - แปลงข้อมูลเป็นตัวเลข (ชื่อ, วันเกิด, บัตรประชาชน)
// 3. Personal Music Library - ระบบคลังเพลงส่วนบุคคล
// 4. UI Helper - ฟังก์ชันช่วยเหลือสำหรับแสดงผล UI
// ------------------------------------------------------------
// อัปเดต: แก้ไขการจัดการข้อมูลส่วนบุคคล แสดงเฉพาะข้อมูลที่มีค่า
// ============================================================

// music-modules.js - เวอร์ชัน 2.5 (Enhanced Personalization with Data Display)
console.log('🎵 Music Modules v2.5 loaded - Enhanced for v5.5');


// ========== FALLBACK FUNCTIONS (ประกาศก่อน) ==========
// ประกาศฟังก์ชัน fallback ก่อนเพื่อป้องกัน error
(function() {
    console.log('Setting up fallback functions...');
    
    // Fallback UIHelper
    window.UIHelper = window.UIHelper || {
        showToast: function(message, type = 'info') {
            console.log(`[Toast ${type}] ${message}`);
            try {
                // สร้าง toast element แบบง่ายๆ
                const toast = document.createElement('div');
                toast.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#3b82f6'};
                    color: white;
                    padding: 12px 16px;
                    border-radius: 8px;
                    z-index: 10000;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                    animation: fadeIn 0.3s;
                `;
                
                const icons = {
                    'success': '✅',
                    'error': '❌',
                    'warning': '⚠️',
                    'info': 'ℹ️'
                };
                
                toast.innerHTML = `
                    <div style="display: flex; align-items: center;">
                        <span style="margin-right: 10px; font-size: 18px;">${icons[type] || 'ℹ️'}</span>
                        <span style="flex: 1;">${message}</span>
                        <button onclick="this.parentElement.parentElement.style.opacity='0'; setTimeout(() => this.parentElement.parentElement.remove(), 300)" 
                                style="background: none; border: none; color: white; font-size: 20px; cursor: pointer; margin-left: 10px; opacity: 0.7;"
                        >×</button>
                    </div>
                `;
                
                document.body.appendChild(toast);
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.style.opacity = '0';
                        toast.style.transition = 'opacity 0.3s';
                        setTimeout(() => {
                            if (toast.parentElement) {
                                toast.remove();
                            }
                        }, 300);
                    }
                }, 5000);
            } catch (e) {
                console.log('Simple toast fallback:', message);
                // Fallback แบบง่ายที่สุด
                alert(`${type === 'error' ? 'ข้อผิดพลาด: ' : type === 'success' ? 'สำเร็จ: ' : ''}${message}`);
            }
        },
        
        showError: function(message) {
            console.error('UI Error:', message);
            this.showToast(message, 'error');
        },
        
        getKeyName: function(key) {
            const keyNames = {
                'C': 'C Major',
                'G': 'G Major',
                'D': 'D Major',
                'Am': 'A Minor',
                'Em': 'E Minor',
                'F': 'F Major'
            };
            return keyNames[key] || key;
        },
        
        getPatternName: function(pattern) {
            const patternNames = {
                'simple': 'เรียบง่าย',
                'arpeggio': 'อาร์เพจจิโอ',
                'chords': 'คอร์ด Lo-fi',
                'ambient': 'แอมเบียนต์',
                'personalized': 'แบบเฉพาะตัว'
            };
            return patternNames[pattern] || pattern;
        }
    };
    
    // Fallback MusicGenerator (เฉพาะฟังก์ชันที่จำเป็นที่สุด)
    if (!window.MusicGenerator) {
        window.MusicGenerator = {
            getLofiScale: function(key) {
                console.log("Fallback getLofiScale called for key:", key);
                const lofiScales = {
                    'C': ['C', 'D', 'E', 'F', 'G', 'A', 'B'],
                    'G': ['G', 'A', 'B', 'C', 'D', 'E', 'F#'],
                    'D': ['D', 'E', 'F#', 'G', 'A', 'B', 'C#'],
                    'Am': ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
                    'Em': ['E', 'F#', 'G', 'A', 'B', 'C', 'D'],
                    'F': ['F', 'G', 'A', 'Bb', 'C', 'D', 'E']
                };
                return lofiScales[key] || lofiScales['Am'];
            },
            
            extractNumbersFromDate: function(dateString) {
                const numbers = [];
                const cleanDate = dateString.replace(/[^0-9]/g, '');
                for (let i = 0; i < cleanDate.length; i++) {
                    const num = parseInt(cleanDate[i]);
                    if (!isNaN(num)) numbers.push(num);
                }
                return numbers;
            },
            
            extractNumbersFromTime: function(timeString) {
                const numbers = [];
                const cleanTime = timeString.replace(/[^0-9]/g, '');
                for (let i = 0; i < cleanTime.length; i++) {
                    const num = parseInt(cleanTime[i]);
                    if (!isNaN(num)) numbers.push(num);
                }
                return numbers;
            },
            
            extractNumbersFromName: function(nameString) {
                const numberMap = {
                    'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8, 'I': 9,
                    'J': 1, 'K': 2, 'L': 3, 'M': 4, 'N': 5, 'O': 6, 'P': 7, 'Q': 8, 'R': 9,
                    'S': 1, 'T': 2, 'U': 3, 'V': 4, 'W': 5, 'X': 6, 'Y': 7, 'Z': 8,
                    '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '0': 0
                };
                
                const numbers = [];
                const upperName = nameString.toUpperCase();
                
                for (let i = 0; i < upperName.length; i++) {
                    const char = upperName[i];
                    if (numberMap[char] !== undefined) {
                        numbers.push(numberMap[char]);
                    }
                }
                
                return numbers;
            }
        };
    }
    
    console.log('✅ Fallback functions setup completed');
})();

// ========== MUSIC GENERATION MODULE ==========
const MusicGenerator = (function() {
    console.log('Initializing MusicGenerator v2.5...');
    
    // ========== UTILITY FUNCTIONS ==========
    const getLofiScale = function(key) {
        console.log("getLofiScale called with key:", key);
        const lofiScales = {
            'C': ['C', 'D', 'E', 'F', 'G', 'A', 'B'],
            'G': ['G', 'A', 'B', 'C', 'D', 'E', 'F#'],
            'D': ['D', 'E', 'F#', 'G', 'A', 'B', 'C#'],
            'Am': ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
            'Em': ['E', 'F#', 'G', 'A', 'B', 'C', 'D'],
            'F': ['F', 'G', 'A', 'Bb', 'C', 'D', 'E']
        };
        return lofiScales[key] || lofiScales['Am'];
    };

    // ฟังก์ชันดึงตัวเลขจากชื่อ-สกุล พร้อมแสดงข้อมูล
    const extractNumbersFromName = function(nameString) {
        const numberMap = {
            'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8, 'I': 9,
            'J': 1, 'K': 2, 'L': 3, 'M': 4, 'N': 5, 'O': 6, 'P': 7, 'Q': 8, 'R': 9,
            'S': 1, 'T': 2, 'U': 3, 'V': 4, 'W': 5, 'X': 6, 'Y': 7, 'Z': 8,
            '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '0': 0
        };
        
        const numbers = [];
        const mappingDetails = [];
        const upperName = nameString.toUpperCase();
        
        for (let i = 0; i < upperName.length; i++) {
            const char = upperName[i];
            if (numberMap[char] !== undefined) {
                numbers.push(numberMap[char]);
                mappingDetails.push(`${char} → ${numberMap[char]}`);
            }
        }
        
        return {
            numbers: numbers,
            details: mappingDetails,
            source: 'ชื่อ-สกุล',
            sourceValue: nameString,
            count: numbers.length
        };
    };

    // ฟังก์ชันดึงตัวเลขจากวันเกิด พร้อมแสดงข้อมูล
    const extractNumbersFromDate = function(dateString) {
        const numbers = [];
        const details = [];
        const cleanDate = dateString.replace(/[^0-9]/g, '');
        
        for (let i = 0; i < cleanDate.length; i++) {
            const num = parseInt(cleanDate[i]);
            if (!isNaN(num)) {
                numbers.push(num);
                details.push(`${cleanDate[i]} (ตำแหน่งที่ ${i+1})`);
            }
        }
        
        return {
            numbers: numbers,
            details: details,
            source: 'วันเกิด',
            sourceValue: dateString,
            count: numbers.length
        };
    };

    // ฟังก์ชันดึงตัวเลขจากเวลาเกิด พร้อมแสดงข้อมูล
    const extractNumbersFromTime = function(timeString) {
        const numbers = [];
        const details = [];
        const cleanTime = timeString.replace(/[^0-9]/g, '');
        
        for (let i = 0; i < cleanTime.length; i++) {
            const num = parseInt(cleanTime[i]);
            if (!isNaN(num)) {
                numbers.push(num);
                details.push(`${cleanTime[i]} (ตำแหน่งที่ ${i+1})`);
            }
        }
        
        return {
            numbers: numbers,
            details: details,
            source: 'เวลาเกิด',
            sourceValue: timeString,
            count: numbers.length
        };
    };

    // ฟังก์ชันดึงตัวเลขจากบัตรประชาชน พร้อมแสดงข้อมูล
    const extractNumbersFromIDCard = function(idCard) {
        const numbers = [];
        const details = [];
        const cleanID = idCard.replace(/[^0-9]/g, '');
        
        for (let i = 0; i < cleanID.length; i++) {
            const num = parseInt(cleanID[i]);
            if (!isNaN(num)) {
                numbers.push(num);
                // ซ่อนบางส่วนของบัตรประชาชนเพื่อความเป็นส่วนตัว
                const displayChar = i < 1 || i > cleanID.length - 5 ? cleanID[i] : 'x';
                details.push(`${displayChar} → ${num}`);
            }
        }
        
        return {
            numbers: numbers,
            details: details,
            source: 'บัตรประชาชน',
            sourceValue: 'xxx-xxx-' + cleanID.slice(-4),
            count: numbers.length
        };
    };

    // ========== ฟังก์ชันใหม่สำหรับเอกลักษณ์เฉพาะบุคคล ==========
    
    // สร้าง unique seed จากข้อมูลทั้งหมด
    const createUniqueSeed = function(numbers, sourceData) {
        console.log("createUniqueSeed called with:", { numbers, sourceData });
        
        try {
            let seedString = '';
            
            // 1. รวมตัวเลขหลักจาก Psychomatrix
            if (numbers.lifePath) seedString += numbers.lifePath.toString();
            if (numbers.destiny) seedString += numbers.destiny.toString();
            if (numbers.lifeLesson) seedString += numbers.lifeLesson.toString();
            if (numbers.karmic) seedString += numbers.karmic.toString();
            
            // 2. เพิ่มข้อมูลวันเกิด
            if (sourceData.birth_date) {
                try {
                    const date = new Date(sourceData.birth_date);
                    seedString += date.getFullYear().toString();
                    seedString += (date.getMonth() + 1).toString().padStart(2, '0');
                    seedString += date.getDate().toString().padStart(2, '0');
                } catch (e) {
                    console.warn('Error parsing birth date:', e);
                    seedString += sourceData.birth_date.replace(/\D/g, '');
                }
            }
            
            // 3. เพิ่มข้อมูลเวลาเกิด
            if (sourceData.birth_time) {
                seedString += sourceData.birth_time.replace(/:/g, '');
            }
            
            // 4. เพิ่มข้อมูลชื่อ (แปลงเป็น ASCII codes)
            if (sourceData.full_name) {
                for (let i = 0; i < Math.min(sourceData.full_name.length, 10); i++) {
                    seedString += sourceData.full_name.charCodeAt(i).toString();
                }
            }
            
            // 5. เพิ่มข้อมูล ID Card
            if (sourceData.id_card) {
                seedString += sourceData.id_card.replace(/\D/g, '');
            }
            
            // สร้าง hash แบบง่าย
            let hash = 2166136261;
            for (let i = 0; i < seedString.length; i++) {
                hash ^= seedString.charCodeAt(i);
                hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
            }
            
            const result = Math.abs(hash >>> 0);
            console.log("Unique seed generated:", result);
            return result;
            
        } catch (error) {
            console.error('Error in createUniqueSeed:', error);
            return Math.abs(Date.now() % 1000000 + Math.floor(Math.random() * 1000));
        }
    };

    // ฟังก์ชันดึงตัวเลขทั้งหมดจากข้อมูลส่วนบุคคล พร้อมรายละเอียด
    const getAllPersonalNumbers = function(numbers, sourceData) {
        const numberSources = [];
        
        // 1. ตัวเลขจาก Psychomatrix
        const psychomatrixNumbers = [
            parseInt(numbers.lifePath) || 1,
            parseInt(numbers.destiny) || 2,
            parseInt(numbers.lifeLesson) || 3,
            parseInt(numbers.karmic) || 4
        ];
        
        numberSources.push({
            source: 'ตัวเลขชีวิต',
            numbers: psychomatrixNumbers,
            details: [
                `Life Path: ${numbers.lifePath || 1}`,
                `Destiny: ${numbers.destiny || 2}`,
                `Life Lesson: ${numbers.lifeLesson || 3}`,
                `Karmic: ${numbers.karmic || 4}`
            ],
            count: 4
        });
        
        // 2. ตัวเลขจากวันเกิด
        if (sourceData.birth_date) {
            const birthData = extractNumbersFromDate(sourceData.birth_date);
            numberSources.push(birthData);
        }
        
        // 3. ตัวเลขจากเวลาเกิด
        if (sourceData.birth_time) {
            const timeData = extractNumbersFromTime(sourceData.birth_time);
            numberSources.push(timeData);
        }
        
        // 4. ตัวเลขจากชื่อ-สกุล
        if (sourceData.full_name) {
            const nameData = extractNumbersFromName(sourceData.full_name);
            numberSources.push(nameData);
        }
        
        // 5. ตัวเลขจากบัตรประชาชน
        if (sourceData.id_card) {
            const idData = extractNumbersFromIDCard(sourceData.id_card);
            numberSources.push(idData);
        }
        
        // รวมตัวเลขทั้งหมด
        const allNumbers = numberSources.flatMap(source => source.numbers);
        
        return {
            allNumbers: allNumbers,
            sources: numberSources,
            totalCount: allNumbers.length
        };
    };

    // สร้าง chord progressions ที่ unique มากขึ้น
    const createUniqueChordProgressions = function(seed, scale) {
        const progressions = [];
        const seedStr = seed.toString();
        
        // สร้าง progression ใหม่จาก seed
        for (let i = 0; i < 4; i++) {
            const chord = [];
            for (let j = 0; j < 3; j++) {
                const charIndex = (i * 3 + j) % seedStr.length;
                const seedDigit = parseInt(seedStr[charIndex]) || 1;
                const index = (seedDigit + i + j) % scale.length;
                const octave = 4 + Math.floor((seedDigit + i + j) / scale.length) % 2;
                chord.push(scale[index] + octave);
            }
            progressions.push(chord);
        }
        
        return progressions;
    };

    // สร้างเมโลดี้ที่ unique มากขึ้น
    const createUniqueMelody = function(seed, scale, chords, personalNumbers) {
        const melody = [];
        const seedStr = seed.toString();
        const noteCount = 16; // ความยาวเมโลดี้
        
        for (let i = 0; i < noteCount; i++) {
            // ผสม seed + personal numbers
            const seedIndex = i % seedStr.length;
            const seedDigit = parseInt(seedStr[seedIndex]) || 1;
            const personalNum = personalNumbers[i % personalNumbers.length] || 1;
            
            // คำนวณ note index จากหลายปัจจัย
            const baseValue = seedDigit + personalNum + i;
            const noteIndex = baseValue % scale.length;
            
            // กำหนด octave แบบไดนามิก
            const octaveShift = Math.floor(seedDigit / 3);
            const octave = 4 + (i % 2) + (octaveShift % 2);
            
            // เลือก note จาก scale
            const note = scale[noteIndex] + octave;
            melody.push(note);
            
            // เพิ่มความหลากหลายด้วย chord tones
            if (i % 3 === 0 && chords && chords[i % chords.length]) {
                const chord = chords[i % chords.length];
                if (chord && chord[i % 3]) {
                    melody.push(chord[i % 3]);
                    i++; // ข้ามไปตัวต่อไป
                }
            }
        }
        
        return melody.slice(0, noteCount);
    };

    // สร้าง chord progressions แบบทั่วไป
    const createPersonalizedChordProgressions = function(numbers, scale, style) {
        const progressions = [
            [[0, 2, 4], [5, 0, 2], [2, 4, 6], [4, 6, 1]],  // i - VI - III - VII
            [[0, 2, 4], [4, 6, 1], [5, 0, 2], [4, 6, 1]],  // i - VII - VI - VII
            [[0, 2, 4], [3, 5, 0], [5, 0, 2], [4, 6, 1]],  // i - iv - VI - v
            [[5, 0, 2], [4, 6, 1], [0, 2, 4], [3, 5, 0]],  // VI - VII - i - iv
            [[0, 2, 4], [2, 4, 6], [5, 0, 2], [3, 5, 0]],  // i - III - VI - iv
        ];
        
        const sum = numbers.reduce((a, b) => a + b, 0);
        const progressionIndex = sum % progressions.length;
        let progression = progressions[progressionIndex];
        
        if (numbers.length >= 4) {
            for (let i = 0; i < Math.min(4, progression.length); i++) {
                if (numbers[i] % 2 === 0) {
                    progression[i] = progression[i].map(index => index);
                }
            }
        }
        
        const chords = progression.map(indices => {
            return indices.map(i => {
                const note = scale[i % scale.length];
                const octave = 4 + Math.floor((i + (numbers[i % numbers.length] || 0)) / scale.length) % 2;
                return note + octave;
            });
        });
        
        return chords;
    };

    const createPersonalizedMelody = function(numbers, scale, chords) {
        const melody = [];
        
        for (let i = 0; i < Math.min(numbers.length, 16); i++) {
            const num = numbers[i];
            const chordIndex = i % chords.length;
            const currentChord = chords[chordIndex];
            
            const noteIndex = num % currentChord.length;
            let note = currentChord[noteIndex];
            
            if (num % 3 === 0) {
                const scaleIndex = (num + i) % scale.length;
                const octave = 4 + Math.floor((num + i) / scale.length) % 2;
                note = scale[scaleIndex] + octave;
            }
            
            melody.push(note);
            
            if (num > 7 && i < numbers.length - 1) {
                const nextNote = getHarmonicNote(note, scale, num % 5);
                melody.push(nextNote);
            }
        }
        
        return melody.slice(0, 16);
    };

    const getHarmonicNote = function(baseNote, scale, interval) {
        const noteName = baseNote.replace(/\d/, '');
        const octave = parseInt(baseNote.match(/\d/)?.[0]) || 4;
        const baseIndex = scale.indexOf(noteName);
        
        if (baseIndex === -1) return baseNote;
        
        const intervals = [3, 4, 5, 7];
        const chosenInterval = intervals[interval % intervals.length];
        const newIndex = (baseIndex + chosenInterval) % scale.length;
        const newOctave = octave + Math.floor((baseIndex + chosenInterval) / scale.length);
        
        return scale[newIndex] + newOctave;
    };

    const createSimpleMelody = function(numbers, scale) {
        const melody = [];
        numbers.forEach(num => {
            const numValue = parseInt(num) || 1;
            const noteIndex = (numValue - 1) % scale.length;
            const octave = 4 + Math.floor(numValue / scale.length);
            melody.push(scale[noteIndex] + octave);
        });
        
        if (melody.length < 4) {
            for (let i = melody.length; i < 4; i++) {
                const noteIndex = i % scale.length;
                melody.push(scale[noteIndex] + '4');
            }
        }
        
        return melody.slice(0, 8);
    };

    const createArpeggio = function(chord) {
        if (!chord || chord.length < 3) return ['C4', 'E4', 'G4', 'C5'];
        return [...chord, chord[0] + '5'];
    };

    const createAmbientPad = function(chords, scale) {
        const padNotes = [];
        chords.forEach(chord => {
            if (chord && chord[0]) {
                const note = chord[0].replace('4', '3');
                padNotes.push(note);
            }
        });
        return padNotes;
    };

    const addLofiVariation = function(melody, style) {
        return melody.map((note, index) => {
            if (style === 'lofi' && Math.random() > 0.7) {
                return note;
            }
            return note;
        });
    };

    const createPersonalizedBassLine = function(chords, numbers, pattern) {
        const bassNotes = [];
        
        chords.forEach((chord, index) => {
            if (chord && chord[0]) {
                let root = chord[0].replace('4', '2');
                const num = numbers[index % numbers.length] || 1;
                
                if (num % 4 === 0 && pattern === 'rootFifth') {
                    const fifth = getFifth(root);
                    bassNotes.push(fifth);
                    bassNotes.push(root);
                } else if (num % 3 === 0 && pattern === 'arpeggio') {
                    bassNotes.push(root);
                    bassNotes.push(chord[1].replace('4', '2'));
                    bassNotes.push(chord[2].replace('4', '2'));
                } else {
                    bassNotes.push(root);
                    if (num % 5 === 0) {
                        const passingNote = getPassingNote(root, chord[1].replace('4', '2'));
                        bassNotes.push(passingNote);
                    }
                }
            }
        });
        
        return bassNotes;
    };

    const getFifth = function(note) {
        const notes = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
        const octave = note.match(/\d/)?.[0] || '2';
        const noteName = note.replace(/\d/, '');
        const index = notes.indexOf(noteName);
        
        if (index === -1) return note;
        
        const fifthIndex = (index + 4) % notes.length;
        const newOctave = (index + 4 >= notes.length) ? parseInt(octave) + 1 : octave;
        
        return notes[fifthIndex] + newOctave;
    };

    const getPassingNote = function(note1, note2) {
        const notes = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
        const note1Name = note1.replace(/\d/, '');
        const note2Name = note2.replace(/\d/, '');
        const octave = note1.match(/\d/)?.[0] || '2';
        
        const index1 = notes.indexOf(note1Name);
        const index2 = notes.indexOf(note2Name);
        
        if (index1 === -1 || index2 === -1) return note1;
        
        const passingIndex = Math.floor((index1 + index2) / 2);
        return notes[passingIndex] + octave;
    };

    const chordToName = function(chord, key) {
        if (!chord || !chord[0]) return '';
        
        const noteMap = {
            'A': 'Am', 'B': 'Bm', 'C': 'C', 'D': 'Dm',
            'E': 'Em', 'F': 'F', 'G': 'G'
        };
        
        const rootNote = chord[0].charAt(0);
        return noteMap[rootNote] || rootNote + 'm';
    };

    // ========== MAIN FUNCTIONS ==========
    
    // ฟังก์ชันหลักใหม่สำหรับสร้างเพลงที่ unique
    const createTrulyPersonalizedMusic = function(numbers, sourceData, settings) {
        console.log("createTrulyPersonalizedMusic called with:", { numbers, sourceData, settings });
        
        try {
            const {
                key = 'Am',
                style = 'lofi',
                pattern = 'personalized',
                tempo = 85
            } = settings || {};
            
            // 1. สร้าง unique seed
            const uniqueSeed = createUniqueSeed(numbers, sourceData);
            
            // 2. ดึง scale
            const scale = getLofiScale(key);
            
            // 3. ดึงตัวเลขทั้งหมดพร้อมแหล่งที่มา
            const personalNumbersData = getAllPersonalNumbers(numbers, sourceData);
            
            // 4. สร้าง chord progressions แบบ unique
            const chords = createUniqueChordProgressions(uniqueSeed, scale);
            
            // 5. สร้างเมโลดี้แบบ unique
            const melody = createUniqueMelody(uniqueSeed, scale, chords, personalNumbersData.allNumbers);
            
            // 6. สร้าง bass line
            const bass = createPersonalizedBassLine(chords, personalNumbersData.allNumbers, 'rootFifth');
            
            // 7. ปรับ tempo ตามอายุ
            let finalTempo = tempo;
            if (sourceData.birth_date) {
                try {
                    const birthDate = new Date(sourceData.birth_date);
                    const age = new Date().getFullYear() - birthDate.getFullYear();
                    finalTempo = Math.max(60, Math.min(120, tempo + (age % 20)));
                } catch (e) {
                    console.warn('Error calculating age from birth date:', e);
                }
            }
            
            // 8. สร้างรายละเอียดข้อมูลที่ใช้สร้างโน้ต
            const usedDataDetails = personalNumbersData.sources.map(source => ({
                source: source.source,
                numbers: source.numbers,
                count: source.count,
                details: source.details,
                sourceValue: source.sourceValue
            }));
            
            // สร้าง personalInfo object แบบมีเงื่อนไข
            const personalInfo = {
                uniqueId: 'MUSIC-' + uniqueSeed.toString().slice(0, 8)
            };
            
            // เพิ่มชื่อถ้ามี
            if (sourceData.full_name && sourceData.full_name.trim() !== '') {
                personalInfo.name = sourceData.full_name.trim();
            }
            
            // เพิ่มวันเกิดถ้ามี
            if (sourceData.birth_date && sourceData.birth_date.trim() !== '') {
                personalInfo.birthDate = sourceData.birth_date.trim();
            }
            
            // เพิ่มบัตรประชาชนถ้ามี
            if (sourceData.id_card && sourceData.id_card.trim() !== '') {
                const idCard = sourceData.id_card.trim().replace(/\D/g, '');
                if (idCard.length >= 4) {
                    personalInfo.idCard = 'xxx-xxx-' + idCard.slice(-4);
                }
            }
            
            const result = {
                melody: melody,
                chords: chords.map(chord => chordToName(chord, key)),
                chordNotes: chords,
                bass: bass,
                tempo: finalTempo,
                style: style,
                key: key,
                uniqueSeed: uniqueSeed,
                personalInfo: personalInfo,
                usedData: usedDataDetails,
                generatorVersion: '2.5 - Truly Personalized',
                usedNumbers: personalNumbersData.allNumbers,
                totalNumberCount: personalNumbersData.totalCount,
                pattern: pattern
            };
            
            console.log("createTrulyPersonalizedMusic result:", result);
            return result;
            
        } catch (error) {
            console.error('Error in createTrulyPersonalizedMusic:', error);
            throw error;
        }
    };

    // ฟังก์ชันดั้งเดิม (คงไว้สำหรับ compatibility)
    const createPersonalizedLofiMusic = function(numbers, sourceData, key, pattern, style, tempo) {
        console.log("createPersonalizedLofiMusic called with:", { 
            numbers, sourceData, key, pattern, style, tempo 
        });
        
        try {
            const styleConfig = window.MUSIC_STYLES?.[style] || {
                name: 'Lo-fi Beats',
                drumPattern: [1, 0, 1, 0, 1, 0, 1, 0],
                hihatPattern: [1, 1, 1, 1, 1, 1, 1, 1],
                snarePattern: [0, 0, 1, 0, 0, 0, 1, 0],
                bassPattern: 'rootFifth'
            };
            
            const scale = getLofiScale(key);
            
            // ดึงตัวเลขทั้งหมดพร้อมแหล่งที่มา
            const personalNumbersData = getAllPersonalNumbers(numbers, sourceData);
            const allNumbers = personalNumbersData.allNumbers;
            
            const chords = createPersonalizedChordProgressions(allNumbers, scale, style);
            
            let melody = [];
            if (pattern === 'personalized') {
                melody = createPersonalizedMelody(allNumbers, scale, chords);
            } else if (pattern === 'chords') {
                melody = chords.flat().slice(0, 12);
            } else if (pattern === 'arpeggio') {
                melody = createArpeggio(chords[0] || ['A4', 'C4', 'E4']);
            } else if (pattern === 'ambient') {
                melody = createAmbientPad(chords, scale);
            } else {
                melody = createSimpleMelody(allNumbers.slice(0, 8), scale);
            }
            
            melody = addLofiVariation(melody, style);
            
            const bass = createPersonalizedBassLine(chords, allNumbers, styleConfig.bassPattern);
            
            const avgNumber = allNumbers.reduce((a, b) => a + b, 0) / allNumbers.length;
            const dynamicTempo = avgNumber > 5 ? Math.min(120, tempo + 15) : Math.max(70, tempo - 10);
            
            // สร้าง personalInfo object แบบมีเงื่อนไข
            const personalInfo = {
                uniqueId: 'MUSIC-' + Date.now().toString().slice(-8)
            };
            
            // เพิ่มชื่อถ้ามี
            if (sourceData.full_name && sourceData.full_name.trim() !== '') {
                personalInfo.name = sourceData.full_name.trim();
            }
            
            // เพิ่มวันเกิดถ้ามี
            if (sourceData.birth_date && sourceData.birth_date.trim() !== '') {
                personalInfo.birthDate = sourceData.birth_date.trim();
            }
            
            // เพิ่มบัตรประชาชนถ้ามี
            if (sourceData.id_card && sourceData.id_card.trim() !== '') {
                const idCard = sourceData.id_card.trim().replace(/\D/g, '');
                if (idCard.length >= 4) {
                    personalInfo.idCard = 'xxx-xxx-' + idCard.slice(-4);
                }
            }
            
            const result = {
                melody: melody,
                chords: chords.map(chord => chordToName(chord, key)),
                chordNotes: chords,
                bass: bass,
                drums: styleConfig.drumPattern,
                hihat: styleConfig.hihatPattern,
                snare: styleConfig.snarePattern,
                timeSignature: '4/4',
                bars: 8,
                style: style,
                key: key,
                tempo: dynamicTempo,
                scale: scale,
                usedNumbers: allNumbers.slice(0, 12),
                sourceInfo: {
                    lifePath: numbers.lifePath,
                    destiny: numbers.destiny,
                    lifeLesson: numbers.lifeLesson,
                    karmic: numbers.karmic,
                    birthDate: sourceData.birth_date,
                    birthTime: sourceData.birth_time,
                    fullName: sourceData.full_name,
                    idCard: sourceData.id_card
                },
                personalInfo: personalInfo,
                generatorVersion: '1.0 - Standard',
                pattern: pattern
            };
            
            console.log("createPersonalizedLofiMusic result:", result);
            return result;
            
        } catch (error) {
            console.error('Error in createPersonalizedLofiMusic:', error);
            // Return fallback music
            const personalInfo = {
                uniqueId: 'FB-' + Date.now().toString().slice(-8)
            };
            
            if (sourceData.full_name && sourceData.full_name.trim() !== '') {
                personalInfo.name = sourceData.full_name.trim();
            }
            
            return {
                melody: ['A4', 'C4', 'E4', 'G4', 'F4', 'A4', 'C4', 'E4'],
                chords: ['Am', 'F', 'C', 'G'],
                chordNotes: [
                    ['A4', 'C4', 'E4'],
                    ['F4', 'A4', 'C4'],
                    ['C4', 'E4', 'G4'],
                    ['G4', 'B4', 'D4']
                ],
                bass: ['A2', 'F2', 'C2', 'G2'],
                tempo: tempo || 85,
                style: style || 'lofi',
                key: key || 'Am',
                personalInfo: personalInfo,
                generatorVersion: '1.0 - Fallback'
            };
        }
    };

    // ========== RETURN PUBLIC API ==========
    return {
        // Utility functions
        getLofiScale,
        extractNumbersFromDate,
        extractNumbersFromTime,
        extractNumbersFromName,
        extractNumbersFromIDCard,
        
        // Personalized music functions
        createUniqueSeed,
        getAllPersonalNumbers,
        createTrulyPersonalizedMusic,
        createPersonalizedLofiMusic,
        
        // Helper functions
        createPersonalizedChordProgressions,
        createPersonalizedMelody,
        getHarmonicNote,
        createSimpleMelody,
        createArpeggio,
        createAmbientPad,
        addLofiVariation,
        createPersonalizedBassLine,
        getFifth,
        getPassingNote,
        chordToName
    };
})();

// ========== UI HELPER MODULE ==========
const UIHelper = (function() {
    console.log('Initializing UIHelper v2.5...');
    
    const showToast = function(message, type = 'info') {
        console.log(`[Toast ${type}] ${message}`);
        
        try {
            // ลองใช้ fallback toast ถ้ามีปัญหา
            const oldToast = document.querySelector('.custom-toast');
            if (oldToast) oldToast.remove();
            
            const toast = document.createElement('div');
            toast.className = `custom-toast ${type}`;
            toast.innerHTML = `
                <div class="toast-content">
                    <span class="toast-icon">
                        ${type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️'}
                    </span>
                    <span class="toast-message">${message}</span>
                    <button onclick="this.parentElement.parentElement.remove()" class="toast-close">×</button>
                </div>
            `;
            
            // เพิ่มสไตล์ถ้ายังไม่มี
            if (!document.querySelector('#toast-styles')) {
                const style = document.createElement('style');
                style.id = 'toast-styles';
                style.textContent = `
                    .custom-toast {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        z-index: 9999;
                        min-width: 300px;
                        max-width: 400px;
                        animation: slideIn 0.3s ease;
                    }
                    .custom-toast.success {
                        background: linear-gradient(135deg, #10b981, #059669);
                        color: white;
                        border-left: 4px solid #047857;
                    }
                    .custom-toast.error {
                        background: linear-gradient(135deg, #ef4444, #dc2626);
                        color: white;
                        border-left: 4px solid #b91c1c;
                    }
                    .custom-toast.info {
                        background: linear-gradient(135deg, #3b82f6, #2563eb);
                        color: white;
                        border-left: 4px solid #1d4ed8;
                    }
                    .custom-toast.warning {
                        background: linear-gradient(135deg, #f59e0b, #d97706);
                        color: white;
                        border-left: 4px solid #b45309;
                    }
                    .toast-content {
                        padding: 12px 16px;
                        border-radius: 8px;
                        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                    }
                    .toast-icon {
                        margin-right: 10px;
                        font-size: 18px;
                    }
                    .toast-message {
                        flex: 1;
                        font-size: 14px;
                    }
                    .toast-close {
                        background: none;
                        border: none;
                        color: white;
                        font-size: 20px;
                        cursor: pointer;
                        margin-left: 10px;
                        opacity: 0.7;
                    }
                    .toast-close:hover {
                        opacity: 1;
                    }
                    @keyframes slideIn {
                        from {
                            transform: translateX(100%);
                            opacity: 0;
                        }
                        to {
                            transform: translateX(0);
                            opacity: 1;
                        }
                    }
                `;
                document.head.appendChild(style);
            }
            
            document.body.appendChild(toast);
            
            // อัตโนมัติลบหลังจาก 5 วินาที
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 5000);
            
            return toast;
        } catch (error) {
            console.error('Toast error, using fallback:', error);
            // Fallback แบบง่ายๆ
            try {
                const fallbackToast = document.createElement('div');
                fallbackToast.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#3b82f6'};
                    color: white;
                    padding: 12px 16px;
                    border-radius: 8px;
                    z-index: 10000;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                `;
                fallbackToast.textContent = message;
                document.body.appendChild(fallbackToast);
                setTimeout(() => {
                    if (fallbackToast.parentNode) {
                        fallbackToast.parentNode.removeChild(fallbackToast);
                    }
                }, 3000);
            } catch (e) {
                console.log('Ultimate fallback toast:', message);
            }
        }
    };

    const showError = function(message) {
        console.error('Error:', message);
        this.showToast(message, 'error');
    };

    const getKeyName = function(key) {
        const keyNames = {
            'C': 'C Major',
            'G': 'G Major',
            'D': 'D Major',
            'Am': 'A Minor',
            'Em': 'E Minor',
            'F': 'F Major'
        };
        return keyNames[key] || key;
    };

    const getPatternName = function(pattern) {
        const patternNames = {
            'simple': 'เรียบง่าย',
            'arpeggio': 'อาร์เพจจิโอ',
            'chords': 'คอร์ด Lo-fi',
            'ambient': 'แอมเบียนต์',
            'personalized': 'แบบเฉพาะตัว',
            'trulyPersonalized': 'เอกลักษณ์แท้'
        };
        return patternNames[pattern] || pattern;
    };

    const renderPersonalMusicCard = function(music, index = 0, userId = null) {
        const date = music.savedAt ? new Date(music.savedAt).toLocaleDateString('th-TH') : 'ไม่ระบุวันที่';
        
        return `
            <div class="bg-white rounded-xl shadow-lg p-4 mb-4 border border-gray-200 hover:border-blue-300 transition-colors">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <h4 class="font-bold text-gray-800">เพลงที่ ${index + 1}</h4>
                        <div class="text-xs text-gray-500 mt-1">สร้างเมื่อ: ${date}</div>
                    </div>
                    <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">${music.generatorVersion || 'เวอร์ชัน 1.0'}</span>
                </div>
                
                <div class="mb-3">
                    <div class="text-sm text-gray-600 mb-1">เมโลดี้ (8 โน้ตแรก):</div>
                    <div class="font-mono text-xs bg-gray-50 p-2 rounded truncate">
                        ${music.melody.slice(0, 8).join(' - ')}
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-2 text-sm mb-3">
                    <div class="bg-gray-50 p-2 rounded">
                        <div class="text-gray-500">คีย์</div>
                        <div class="font-bold">${getKeyName(music.key)}</div>
                    </div>
                    <div class="bg-gray-50 p-2 rounded">
                        <div class="text-gray-500">ความเร็ว</div>
                        <div class="font-bold">${music.tempo} BPM</div>
                    </div>
                </div>
                
                <div class="flex gap-2">
                    <button onclick="playSavedMusic(${index}, '${userId}')" 
                            class="flex-1 bg-green-500 hover:bg-green-600 text-white text-sm py-2 px-3 rounded transition duration-300">
                        <i class="fas fa-play mr-1"></i> เล่น
                    </button>
                    <button onclick="deleteSavedMusic(${index}, '${userId}')" 
                            class="bg-red-500 hover:bg-red-600 text-white text-sm py-2 px-3 rounded transition duration-300">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    };

    const renderMusicLibrary = function(userId) {
        const library = PersonalMusicLibrary ? PersonalMusicLibrary.getPersonalMusics(userId) : [];
        
        if (!library || library.length === 0) {
            return `
                <div class="text-center py-8">
                    <div class="text-4xl mb-4">🎵</div>
                    <p class="text-gray-600">ยังไม่มีเพลงที่บันทึกไว้</p>
                    <p class="text-sm text-gray-400 mt-2">สร้างเพลงใหม่และบันทึกเพื่อเก็บไว้ในคลัง</p>
                </div>
            `;
        }
        
        return `
            <div class="mb-4">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="font-bold text-gray-800">📚 คลังเพลงของฉัน (${library.length} เพลง)</h3>
                    <button onclick="clearMusicLibrary('${userId}')" 
                            class="text-sm text-red-500 hover:text-red-700">
                        ล้างทั้งหมด
                    </button>
                </div>
                <div class="space-y-4">
                    ${library.map((music, index) => renderPersonalMusicCard(music, index, userId)).join('')}
                </div>
            </div>
        `;
    };

    return {
        showToast,
        showError,
        getKeyName,
        getPatternName,
        renderPersonalMusicCard,
        renderMusicLibrary
    };
})();

// ========== PERSONAL MUSIC LIBRARY MODULE ==========
const PersonalMusicLibrary = (function() {
    console.log('Initializing PersonalMusicLibrary v2.5...');
    
    // บันทึกเพลงของแต่ละคน
    const savePersonalMusic = function(musicData, userId) {
        try {
            const library = getLibrary();
            const userKey = userId || musicData.personalInfo?.uniqueId || 'anonymous';
            
            if (!library[userKey]) {
                library[userKey] = [];
            }
            
            // จำกัดจำนวนเพลงต่อคน
            if (library[userKey].length >= 10) {
                library[userKey].shift(); // ลบเพลงเก่าที่สุด
            }
            
            library[userKey].push({
                ...musicData,
                savedAt: new Date().toISOString()
            });
            
            localStorage.setItem('personalMusicLibrary', JSON.stringify(library));
            return library[userKey].length;
        } catch (error) {
            console.error('Error saving music to library:', error);
            return 0;
        }
    };
    
    // โหลดเพลงทั้งหมดของบุคคล
    const getPersonalMusics = function(userId) {
        const library = getLibrary();
        return library[userId] || [];
    };
    
    // โหลด library ทั้งหมด
    const getLibrary = function() {
        try {
            const library = localStorage.getItem('personalMusicLibrary');
            return library ? JSON.parse(library) : {};
        } catch {
            return {};
        }
    };
    
    // สร้าง user ID จากข้อมูลส่วนบุคคล
    const createUserId = function(sourceData) {
        if (!sourceData) return null;
        
        const parts = [];
        if (sourceData.birth_date) parts.push(sourceData.birth_date.replace(/\D/g, '').slice(0, 8));
        if (sourceData.full_name) parts.push(btoa(sourceData.full_name.slice(0, 5)).slice(0, 8).replace(/[^a-zA-Z0-9]/g, ''));
        if (sourceData.id_card) parts.push(sourceData.id_card.slice(-4));
        
        return parts.length > 0 ? parts.join('-') : 'user-' + Date.now().toString().slice(-8);
    };
    
    // ลบเพลงของบุคคล
    const deleteMusic = function(userId, index) {
        try {
            const library = getLibrary();
            if (library[userId] && library[userId][index]) {
                library[userId].splice(index, 1);
                localStorage.setItem('personalMusicLibrary', JSON.stringify(library));
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error deleting music:', error);
            return false;
        }
    };
    
    // นับจำนวนเพลงทั้งหมด
    const getTotalMusicCount = function() {
        const library = getLibrary();
        let count = 0;
        for (const user in library) {
            count += library[user].length;
        }
        return count;
    };
    
    return {
        savePersonalMusic,
        getPersonalMusics,
        getLibrary,
        createUserId,
        deleteMusic,
        getTotalMusicCount
    };
})();

// ========== EXPORT MODULES ==========
if (typeof window !== 'undefined') {
    // รวมฟังก์ชันจาก MusicGenerator เข้ากับ window.MusicGenerator
    window.MusicGenerator = Object.assign({}, window.MusicGenerator, MusicGenerator);
    
    // รวมฟังก์ชันจาก UIHelper เข้ากับ window.UIHelper
    window.UIHelper = Object.assign({}, window.UIHelper, UIHelper);
    
    // ส่งออก PersonalMusicLibrary
    window.PersonalMusicLibrary = PersonalMusicLibrary;
    
    // ฟังก์ชัน helper สำหรับใช้งานจากภายนอก
    window.playSavedMusic = function(index, userId) {
        const library = PersonalMusicLibrary.getPersonalMusics(userId);
        if (library && library[index]) {
            // ตั้งค่าให้เล่นเพลงที่เลือก
            if (window.currentMusic !== undefined) {
                window.currentMusic = library[index];
            }
            
            sessionStorage.setItem('generatedMusic', JSON.stringify(library[index]));
            
            if (window.safePlayMusic) {
                window.safePlayMusic();
            }
            
            if (window.UIHelper && window.UIHelper.showToast) {
                window.UIHelper.showToast(`กำลังเล่นเพลงที่ ${index + 1}`, 'info');
            }
        }
    };
    
    window.deleteSavedMusic = function(index, userId) {
        if (confirm('คุณแน่ใจหรือว่าต้องการลบเพลงนี้?')) {
            const success = PersonalMusicLibrary.deleteMusic(userId, index);
            if (success) {
                if (window.UIHelper && window.UIHelper.showToast) {
                    window.UIHelper.showToast('ลบเพลงสำเร็จ', 'success');
                }
                // รีเฟรช UI
                if (typeof renderMusicLibraryUI === 'function') {
                    renderMusicLibraryUI();
                }
            }
        }
    };
    
    window.clearMusicLibrary = function(userId) {
        if (confirm('คุณแน่ใจหรือว่าต้องการลบเพลงทั้งหมด?')) {
            localStorage.removeItem('personalMusicLibrary');
            if (window.UIHelper && window.UIHelper.showToast) {
                window.UIHelper.showToast('ล้างคลังเพลงสำเร็จ', 'success');
            }
            // รีเฟรช UI
            if (typeof renderMusicLibraryUI === 'function') {
                renderMusicLibraryUI();
            }
        }
    };
    
    console.log('✅ Music Modules v2.5 loaded successfully');
    console.log('MusicGenerator functions available:', Object.keys(window.MusicGenerator || {}).length);
    console.log('UIHelper functions available:', Object.keys(window.UIHelper || {}).length);
    console.log('PersonalMusicLibrary available:', !!window.PersonalMusicLibrary);
}

// ========== DEBUG & VERIFICATION ==========
console.log('🎵 Music Modules v2.5 - Enhanced Personalization with Data Display');
console.log('Checking critical functions in MusicGenerator:');

// ตรวจสอบฟังก์ชันสำคัญ
const criticalFunctions = [
    'getLofiScale',
    'createUniqueSeed',
    'createTrulyPersonalizedMusic',
    'createPersonalizedLofiMusic'
];

criticalFunctions.forEach(func => {
    if (window.MusicGenerator && typeof window.MusicGenerator[func] === 'function') {
        console.log(`✅ MusicGenerator.${func} is available`);
    } else {
        console.warn(`⚠️ MusicGenerator.${func} is NOT available`);
    }
});

// เพิ่ม animation style สำหรับ toast
if (typeof document !== 'undefined') {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    `;
    document.head.appendChild(style);
}